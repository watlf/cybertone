-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 24, 2016 at 06:28 PM
-- Server version: 5.6.30-0ubuntu0.14.04.1
-- PHP Version: 5.6.23-1+deprecated+dontuse+deb.sury.org~trusty+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cybertone`
--

-- --------------------------------------------------------

--
-- Table structure for table `consumers`
--

CREATE TABLE IF NOT EXISTS `consumers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned DEFAULT NULL,
  `login` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `account_expired` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `avatar_extension` char(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`,`email`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=38 ;

--
-- Dumping data for table `consumers`
--

INSERT INTO `consumers` (`id`, `group_id`, `login`, `password`, `email`, `account_expired`, `avatar_extension`) VALUES
(1, NULL, 'audi', '$2y$10$cmFuZG9tIHZhbHVlIGhhcuI7ZE2Wq3wFV0MZck7acORnIqaFB16jC', 'audi@mail.com', '2016-07-09 21:00:00', 'jpg'),
(2, NULL, 'acura', '$2y$10$cmFuZG9tIHZhbHVlIGhhcu7zFWZrM82FWtl/ajex0cpcYCPV2TANi', 'acura@mail.com', '2016-07-09 21:00:00', 'jpg'),
(3, NULL, 'skoda', '$2y$10$cmFuZG9tIHZhbHVlIGhhcur5nNsV0ex3YIoXTE9ZV6bz3mHEDpSQS', 'skoda@mail.com', '2016-07-09 21:00:00', 'jpg'),
(26, NULL, 'audi-tesd', '$2y$10$cmFuZG9tIHZhbHVlIGhhcuG/CJCy4RpOZgf671ZYttiph1GXa2DM6', 'audids@mail.com', '2016-07-17 21:00:00', 'png'),
(27, NULL, 'audi-tesdq', '$2y$10$cmFuZG9tIHZhbHVlIGhhcuG/CJCy4RpOZgf671ZYttiph1GXa2DM6', 'audidsq@mail.com', '2016-07-17 21:00:00', 'png'),
(28, NULL, 'audsi-tesdq', '$2y$10$cmFuZG9tIHZhbHVlIGhhcuG/CJCy4RpOZgf671ZYttiph1GXa2DM6', 'audsidsq@mail.com', '2016-07-17 21:00:00', 'png'),
(29, NULL, 'aAudsi-tesdq', '$2y$10$cmFuZG9tIHZhbHVlIGhhcuG/CJCy4RpOZgf671ZYttiph1GXa2DM6', 'audsAidsq@mail.com', '2016-07-17 21:00:00', 'png'),
(30, NULL, 'aaaa', '$2y$10$cmFuZG9tIHZhbHVlIGhhcu4VPXOFj47vImyOZvDOZk8z6.wHuc8h6', 'aaaaaa@mail.com', '2016-07-18 21:00:00', 'png'),
(31, NULL, 'aaaaaaaaa', '$2y$10$cmFuZG9tIHZhbHVlIGhhcuFtQCrNyqFYqfxBNoXbP/Ecsjbe5xbq2', 'aaaaaaa@mail.com', '2016-07-24 21:00:00', 'png'),
(36, NULL, 'ddsada', '$2y$10$cmFuZG9tIHZhbHVlIGhhcue86IofBZdrBLv0q9cfFQct1WKyvUF1e', 'sdsada@dfdf.com', '2016-07-25 21:00:00', 'jpg'),
(37, NULL, 'dsadsa', '$2y$10$cmFuZG9tIHZhbHVlIGhhcuyexRT/jqpmp2HfB7uFKP00uuabj4GCK', 'sdsadda@dfdf.com', '2016-07-25 21:00:00', 'jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`) VALUES
(1, 'admin'),
(8, 'test2142'),
(2, 'user'),
(7, 'user-1');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `consumers`
--
ALTER TABLE `consumers`
  ADD CONSTRAINT `consumers_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
